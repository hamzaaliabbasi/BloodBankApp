//
//  updateAccount.swift
//  BloodBanking
//
//  Created by Techsviewer on 9/20/18.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit
import Firebase
import SDWebImage
import CoreData

class updateAccount: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate {
   
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    var acc:Array<Account>!
    let appdele = UIApplication.shared.delegate as! AppDelegate
    var dhuzz:Int!
    var pick = UIPickerView()
    var cur = Int()
    var blood = ["A","AB","O","B"]
    var r = ["+","-"]
    var donor = ["Donor","Reciever"]
    var Status = ["Available","Unavailable"]
    var category:Bool!
     var context:NSManagedObjectContext!
    var message:Int!
 var fetch:NSFetchRequest<Account>!
    var current : Bool!
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (cur == 1){return blood.count}
        else if(cur == 2){
            return r.count}
        else if(cur == 3)
        {return donor.count}
        else if(cur == 4)
        {return Status.count}
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(cur == 1){return blood[row]}
        else if(cur == 2)
        {return r[row]}
        else if(cur == 3) {
            return donor[row]
        }
        else if(cur == 4) {
            return Status[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(cur == 1){
            bgtext.text = blood[row]
        }
        else if(cur == 2) {
            rhtext.text = r[row]
        }
        else if(cur == 3)
        {isDonor.text = donor[row]
          }
        else if(cur == 4)
        { self.status.text = Status[row]
        }
      pick.isHidden = true
 self.view.endEditing(true)
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField.tag == 1
        {cur = 1}
        else if textField.tag == 2
        {cur = 2}
        else if textField.tag == 3
        {cur = 3}
        else if textField.tag == 4
        {cur = 4}
     pick.reloadAllComponents()
        return true
    }
    

    
    override func viewDidLoad() {
         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Logout", style: .bordered, target: nil, action: nil)
        self.hideKeyboardWhenTappedAround()
        context = appdele.persistentContainer.viewContext
 fetch = Account.fetchRequest()
        message = appdele.mess
        super.viewDidLoad()
        bgtext.tag = 1
        rhtext.tag = 2
        isDonor.tag = 3
        status.tag = 4
let x = data.shareObject.arr[message]
        images.delegate = self
        self.username.text = x.name
        self.email.text = x.email
        pick.dataSource = self
        pick.delegate = self
self.age.text = x.age
        self.bgtext.text = x.bloodgroup
        self.rhtext.text = x.rh

        
        
        
        let url1 : URL = URL(string:x.uImage)!
        
     photo.sd_setBackgroundImage(with: url1, for: .normal, completed: nil)
                   

        
    
         if(x.isDonor)
         { self.isDonor.text = "Donor"}
         else{
            self.isDonor.text = "Reciever"
        }
        if(x.status)
        {self.status.text = Status[0]}
        else{self.status.text = Status[1]}
        self.status.inputView = pick
        self.bgtext.inputView = pick
        self.rhtext.inputView = pick
        self.isDonor.inputView = pick
        self.bgtext.delegate = self
        self.rhtext.delegate = self
        self.isDonor.delegate = self
        self.status.delegate = self
        bgtext.text = self.blood[0]
        rhtext.text = self.r[0]
        isDonor.text = self.donor[0]
        self.dhuzz = 0
    }
let images = UIImagePickerController()

    @IBOutlet weak var photo: UIButton!
    @IBAction func updatePhoto(_ sender: Any) {
        dhuzz = 1
        present(images, animated: true, completion: nil)
    }
    @IBOutlet weak var status: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var isDonor: UITextField!
    var pass = Int()
    @IBOutlet weak var rhtext: UITextField!
    @IBOutlet weak var bgtext: UITextField!
    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBAction func reset_Password(_ sender: Any) {
         let sv = UIViewController.displaySpinner(onView: self.view)
        Auth.auth().sendPasswordReset(withEmail:data.shareObject.arr[self.appdele.mess].email!, completion: { (error) in
            if error != nil{
                let resetFailedAlert = UIAlertController(title: "Reset Failed", message: "Error: \(String(describing: error?.localizedDescription))", preferredStyle: .alert)
                resetFailedAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(resetFailedAlert, animated: true, completion: nil)
                  UIViewController.removeSpinner(spinner: sv)
            }else {
                let resetEmailSentAlert = UIAlertController(title: "Reset email sent successfully", message: "Check your email", preferredStyle: .alert)
                resetEmailSentAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(resetEmailSentAlert, animated: true, completion: nil)
                  UIViewController.removeSpinner(spinner: sv)
            }
        })
       
    }
    @IBAction func update(_ sender: Any) {
     if (self.username.text ==  "" || self.email?.text == "" || self.age?.text == "")// || self.password?.text == "")
        {self.alertMsg(userMessage: "You can't let any field to remain empty")
            return
     }
        else{
       
            let sv = UIViewController.displaySpinner(onView: self.view)
      Auth.auth().currentUser?.updateEmail(to: self.email.text! , completion: nil)
      
        
        if (isDonor.text == donor[0])
        {category = true}
        else{ category = false}
        if (status.text == Status[0])
        {current = true}
        else{ current = false}
        
        var a = data.shareObject.arr
a[message].age = self.age.text
a[message].bloodgroup = self.bgtext.text
        a[message].email = self.email.text
        a[message].isDonor = self.category
        a[message].name = self.username.text
        a[message].rh = self.rhtext.text
        a[message].status = self.current
      
         //  a[message].password = self.password.text
        let d = Auth.auth().currentUser?.uid
        let ref = Database.database().reference().child("user/\(d!)")
       
     
        if(dhuzz == 1)
        
        {
        var storageRef = Storage.storage().reference().child(d!)
        let uploadData = UIImageJPEGRepresentation(self.photo.currentBackgroundImage!,0.2)
        let uploadTask = storageRef.putData(uploadData!, metadata: nil) { (metadata, error) in
           if error == nil
           {
        //                let size = metadata.size
        storageRef.downloadURL(completion: { (url, error) in
            if error != nil {
                print("yeh lo bhae",error!.localizedDescription)
                 UIViewController.removeSpinner(spinner: sv)
                self.alertMsg(userMessage: "Oops some error occured while updating your account")
                return
                
                
                
            }
            
            if let profileImageUrl = url?.absoluteString {
                print("yeh hai bhai", profileImageUrl)
                let values = [
                    "age" : self.age.text as! String,
                    "bloodgrp" : self.bgtext.text as! String,
                    "name" : self.username.text as! String,
                    "email" : self.email.text as! String,
                    "rh" : self.rhtext.text as! String,
                    "status" : self.current! as! Bool,
                "image" : profileImageUrl as! String,
                    "isDonor" : self.category! as! Bool
                    ] as [String : Any]
                
                ref.updateChildValues(values)
                data.shareObject.arr[self.message].uImage = profileImageUrl
                
                self.acc = try! self.context.fetch(self.fetch)
                if self.acc.count > 0
                {for i in self.acc
                {if i.id == Auth.auth().currentUser?.uid
                {
                    i.setValue( profileImageUrl, forKey: "image")
                    i.setValue(self.email.text!, forKey: "email")
                    i.setValue( self.age.text!, forKey: "age")
                    i.setValue(self.bgtext.text!, forKey: "bloodgrp")
                    i.setValue( self.rhtext.text!, forKey: "rh")
                    i.setValue(self.username.text!, forKey: "name")
                    i.setValue( self.current! , forKey: "status")
                    i.setValue(self.category!, forKey: "isDonor")
                    try!self.context.save() }
                    
                    }
                    
                }
                
                
                
            }
           
            
            
            
              UIViewController.removeSpinner(spinner: sv)
            self.update_alert(userMessage: "Your Account has updated with new profile image")
        }
            )}}
            dhuzz = 0
        }
        else{
            let values = [
                "age" : self.age.text as! String,
                "bloodgrp" : self.bgtext.text as! String,
                "name" : self.username.text as! String,
                "email" : self.email.text as! String,
                "rh" : self.rhtext.text as! String,
                "status" : true as! Bool,
                "image" : data.shareObject.arr[self.appdele.mess].uImage as! String,
                "isDonor" : self.category! as! String,
                "status" : self.current! as! String
                ] as [String : Any]
            
            ref.updateChildValues(values)
                UIViewController.removeSpinner(spinner: sv)
               self.update_alert(userMessage: "Your Account has updated")
            }
            print("yahan tk agae")
            
        
        }
 }
    
    
    
    @IBAction func logot(_ sender: Any) {
        
        
        do {
            try Auth.auth().signOut()
            
        } catch (let error) {
            print((error as NSError).code)
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "login") as! ViewController
        
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        photo.setBackgroundImage(UIImage(), for: .disabled)
        let selected = info[UIImagePickerControllerOriginalImage] as! UIImage
        photo.setBackgroundImage(selected, for: .normal)
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func alertMsg(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Error", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        myAlert.addAction(okAction)
        present(myAlert, animated: true, completion: nil)
        
    }
    func update_alert(userMessage:String)
    {
        let myAlert = UIAlertController(title: "", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        myAlert.addAction(okAction)
        present(myAlert, animated: true, completion: nil)
        
    }
    
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
  
    
    
    
    
    
    
    
    
}
