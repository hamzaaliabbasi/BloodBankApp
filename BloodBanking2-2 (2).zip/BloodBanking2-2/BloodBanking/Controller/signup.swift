//
//  signup.swift
//  omer
//
//  Created by AxiomHK40 on 10/06/2018.
//  Copyright © 2018 AxiomHK40. All rights reserved.
//

import UIKit
import  CoreData
import Firebase
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth


class signup: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate  {
    
    
    var url:String!
    var ref:DatabaseReference!
    
    //let appdele = UIApplication.shared.delegate as! AppDelegate
    var entry:Int!
    var cur = Int()
    var blood = ["A","AB","O","B"]
    var r = ["+","-"]
    var donor = ["Donor","Reciever"]
    var Status = ["Available","Unavailable"]
    var current : Bool!

   
    var category:Bool!
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
    return 1    }
    
    @IBOutlet weak var status: UITextField!
    
    @IBOutlet weak var rhtext: UITextField!
    @IBOutlet weak var bgtext: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var age: UITextField!
    var bloodgroup = UIPickerView()
 var k:String!
    @IBOutlet weak var isDonor: UITextField!
    @IBOutlet weak var imageDR: UIImageView!
    let images = UIImagePickerController()
    
    @IBAction func createacc(_ sender: Any) {
        if (self.username.text ==  "" || self.email?.text == "" || self.age?.text == "" || self.password?.text == "")
        {alertMsg(userMessage: "You can't let any field to remain empty")}
            else if(self.password.text!.count < 6)
        {alertMsg(userMessage: "Password length should be greater than 5")
            
        
        }
        else{
            let sv = UIViewController.displaySpinner(onView: self.view)
            Auth.auth().createUser(withEmail: self.email.text!, password: self.password.text!) { (authResult, error) in
                // ...
                guard let user = authResult?.user else {
                    UIViewController.removeSpinner(spinner: sv)
                    self.alertMsg(userMessage: " Oops something wrong happened")
                    
                    return }
            }
           
            if(entry == 0)
            {
                
                print("han bhai")
                if (isDonor.text == donor[0])
            {category = true}
                else{ category = false}
                if (status.text == Status[0])
                {current = true}
                else{ current = false}

             var storageRef = Storage.storage().reference().child(self.email.text!)
            let uploadData = UIImageJPEGRepresentation(self.imageDR.image!, 0.2)
            let uploadTask = storageRef.putData(uploadData!, metadata: nil) { (metadata, error) in
              
                
                if(error == nil){
//
            
                storageRef.downloadURL(completion: { (url, error) in
                    if ( error == nil)
                    {
                   print("haan bhai ",url!)
                    if let profileImageUrl = url?.absoluteString {
                        self.k = profileImageUrl
                        print("yeh hai bhai", profileImageUrl)
                     let a = Auth.auth().currentUser?.uid
                        print(a!)
                        let user = [
                            "id": a! as! String,
                            "age" : self.age.text! as! String,
                            "bloodgrp" : self.bgtext.text! as! String,
                            "name" : self.username.text! as! String,
//                            "password" : self.password.text as! String,
                            "email" : self.email.text! as! String,
                            "rh" : self.rhtext.text! as! String,
                            "isDonor" : self.category! as! Bool,
                            "status" : self.current! as! Bool,
                            "image" : self.k! as! String
                            ] as [String : Any]
                        
                        
                        self.ref.child(a!).setValue(user)
                        UIViewController.removeSpinner(spinner: sv)
                        let myAlert = UIAlertController(title: "Done", message: "Acoount Created Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(myAlert: UIAlertAction!) in self.navigationController?.popViewController(animated: true)})
                        myAlert.addAction(okAction)
                        self.present(myAlert, animated: true, completion: nil)
                    
                        
                        
                        }
                        
                    }
                })
                }
                else{
                    UIViewController.removeSpinner(spinner: sv)
                    self.alertMsg(userMessage: " Oops something wrong happened")
                    print("ghalat hogya kch")
                    self.navigationController?.popViewController(animated: true)
                    return
                }
                print(self.entry," yeh hai entry")}
                
          }}
       
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if(segue.identifier == "go")
        {
             data.shareObject.arr.removeAll()
            let Vcnt = segue.destination as! ViewController
//            Vcnt.passvalue = 1
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (cur == 1){return blood.count}
        else if(cur == 2){
            return r.count}
        else if(cur == 3)
        {return donor.count}
        else if(cur == 4)
        {return Status.count}
        return 1
        
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(cur == 1){return blood[row]}
      else if(cur == 2)
        {return r[row]}
        else if(cur == 3) {
            return donor[row]
        }
        else if(cur == 4) {
            return Status[row]
        }
    return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(cur == 1){
            bgtext.text = blood[row]
        }
       else if(cur == 2) {
            rhtext.text = r[row]
        }
        else if(cur == 3)
        {isDonor.text = donor[row] }
        else if(cur == 4)
        {status.text = Status[row] }
     self.view.endEditing(true)
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField.tag == 1
        {cur = 1}
        else if textField.tag == 2
        {cur = 2}
        else if textField.tag == 3
        {cur = 3}
        else if textField.tag == 4
        {cur = 4}
        bloodgroup.reloadAllComponents()
        return true
    }

    override func viewDidLoad() {
        
        ref = Database.database().reference().child("user")
        super.viewDidLoad()
        
      
self.entry = 0
      
    
      self.hideKeyboardWhenTappedAround()
        
   rhtext.tag = 2
        bgtext.tag = 1
        isDonor.tag = 3
        status.tag = 4
        bloodgroup.dataSource=self
        bloodgroup.delegate=self
        images.delegate=self
        rhtext.inputView = bloodgroup
        bgtext.inputView = bloodgroup
        isDonor.inputView = bloodgroup
        status.inputView = bloodgroup
        
      rhtext.delegate = self
        bgtext.delegate = self
        isDonor.delegate = self
        status.delegate = self
        bgtext.text = self.blood[0]
        rhtext.text = self.r[0]
        isDonor.text = self.donor[0]
        status.text = self.Status[1]
        self.imageDR.image = #imageLiteral(resourceName: "iconBtn_iPhoto")
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let selectedimage = info[UIImagePickerControllerOriginalImage] as! UIImage
        imageDR.image = selectedimage
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
  
    }
    @IBAction func selectImage(_ sender: Any) {
    
        present(images, animated: true, completion: nil)
    }
    func alertMsg(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Error", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        myAlert.addAction(okAction)
        present(myAlert, animated: true, completion: nil)
    }

    

    


}
