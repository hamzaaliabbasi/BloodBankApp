//
//  messagepassing.swift
//  BloodBanking
//
//  Created by Techsviewer on 9/20/18.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit

protocol messagepassing {
    func send(mess:Int)
}
