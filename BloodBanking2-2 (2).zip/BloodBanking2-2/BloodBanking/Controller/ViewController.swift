//
//  ViewController.swift
//  BloodBanking
//
//  Created by Techsviewer on 6/11/18.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit
import  CoreData
import Firebase


class ViewController: UIViewController{
    var d:Bool = false
//    var j:Int!
//    var acca:Account!
//     var ref:DatabaseReference!
//     var acc:Array<Account>!
//    var i:Int!
//    var userid:String!
//    var name:String!
//    var email:String!
//    var age:String!
//    var bg:String!
//    var rh:String!
//    var image:String!
//    var isDonor:Bool!
//    var  status:Bool!
//    var password:String!
//    var passvalue:Int!
//    var iimage: String!
//    var ass:updateAccount!
//    
//    let appdele = UIApplication.shared.delegate as! AppDelegate
// 
//    var context:NSManagedObjectContext!
   
    @IBOutlet weak var userLabel: UITextField!
    @IBOutlet weak var passwordLabel: UITextField!
    
    @IBAction func reset_Password(_ sender: Any) {
        
        
        if(userLabel.text! != nil){
            let sv = UIViewController.displaySpinner(onView: self.view)
        Auth.auth().sendPasswordReset(withEmail:self.userLabel.text!, completion: { (error) in
            if error != nil{
                let resetFailedAlert = UIAlertController(title: "Reset Failed", message: "Error: \(String(describing: error?.localizedDescription))", preferredStyle: .alert)
                resetFailedAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(resetFailedAlert, animated: true, completion: nil)
                UIViewController.removeSpinner(spinner: sv)
            }else {
                let resetEmailSentAlert = UIAlertController(title: "Reset email sent successfully", message: "Check your email", preferredStyle: .alert)
                resetEmailSentAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(resetEmailSentAlert, animated: true, completion: nil)
                UIViewController.removeSpinner(spinner: sv)
            }
        })
    }
        else
        {let alert=UIAlertController(title: "Error Login", message: "Enter a valid email", preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)

            
        }
    }
    
    var x:Int!
    var fetch:NSFetchRequest<Account>!
    override func viewDidLoad() {
     self.navigationItem.hidesBackButton = true
       
        
        
       
        
      

//         ref = Database.database().reference().child("user")
//      context = appdele.persistentContainer.viewContext
    self.userLabel.text = ""
       self.passwordLabel.text = ""
//        self.appdele.mess = 0
//    fetch = Account.fetchRequest()
//        self.j = 0
//  observe()
//        data.shareObject.getData()
      self.hideKeyboardWhenTappedAround()
        super.viewDidLoad()
      
       
        
        
            
        }//viewdidload ends
   
  
    
    
//    func newcheck()
//    {
//        self.i = 0
//        print("bahr agae")
//        self.acc = try! self.context.fetch(self.fetch)
//        print(self.acc.count)
//
//        print(self.acc.count,"yeh hai count")
//
//        if (self.acc.count == 0 && self.appdele.arr.count > 0)
//        {
//            for s in stride(from: 0, to: self.appdele.arr.count, by:1)
//            {
//              acca = Account(context: self.context)
//                self.acca.id = self.appdele.arr[s].id!
//           self.acca.age = self.appdele.arr[s].age!
//                self.acca.bloodgrp = self.appdele.arr[s].bloodgroup!
//                self.acca.email = self.appdele.arr[s].email!
//                //   self.acca.image = self.image
//                self.acca.isDonor = self.appdele.arr[s].isDonor!
//                self.acca.name = self.appdele.arr[s].name!
//              //  self.acca.password = self.appdele.arr[s].password!
//                self.acca.rh = self.appdele.arr[s].rh!
//                self.acca.status = self.appdele.arr[s].status!
//                self.acca.image = self.appdele.arr[s].uImage!
//                try! self.context.save()
//                self.acc = try! self.context.fetch(self.fetch)
//                print(self.acc[s].name,self.acc.count)
//
//            }//for
//            }//if
//
//
//        else
//        { var lokey = [Int]()
//            var yeh = 0
//            print("else chl gya hai bhae")
//                self.acc = try! self.context.fetch(self.fetch)
//            print ("count is greater than one")
//                if(appdele.arr.count > self.acc.count)
//                {print("yeh dekho")
//                 for y in stride(from: 0, to: self.appdele.arr.count, by:1)
//                        {yeh = 0
//                        for i in acc
//                        {
//                            if(i.id == self.appdele.arr[y].id)
//                        {yeh = 1}
//                            }
//                            if( yeh == 0 )
//                            {lokey.append(y)
//                            }
//            }
//
//                        for p in lokey
//                    {
//                     acca = Account(context: self.context)
//                        self.acca.id = self.appdele.arr[p].id
//                         self.acca.age = self.appdele.arr[p].age
//                        self.acca.bloodgrp = self.appdele.arr[p].bloodgroup
//                        self.acca.email = self.appdele.arr[p].email
//                        self.acca.image = self.appdele.arr[p].uImage
//                        self.acca.isDonor = self.appdele.arr[p].isDonor
//                        self.acca.name = self.appdele.arr[p].name
//
//                        self.acca.rh = self.appdele.arr[p].rh
//                       self.acca.status = self.appdele.arr[p].status
//                        self.acca.image = self.appdele.arr[p].uImage
//                        print(self.acca.name!,p)
//                        try! self.context.save()
//
//                    }
//}
//
//        }//else
//        self.j = 5
//    }//newcheck
//
//    func observe()
//    {
//     if(j < 5)
//     {print ("mazeed lg gae")
//        self.i = 0
//        ref.observe(.value, with: {(snapshot) in
//            if (snapshot.childrenCount > 0)
//            {print("kutto waly lag gaye")
//               self.appdele.arr.removeAll()
//                for user in snapshot.children.allObjects as! [DataSnapshot]
//                {let userobj = user.value as? [String:Any]
//                    self.userid = userobj?["id"] as! String
//                    self.name = userobj?["name"] as! String
//                    self.email = userobj?["email"] as! String
//                    self.age = userobj?["age"] as! String
//                    self.bg = userobj?["bloodgrp"] as! String
//                    self.rh = userobj!["rh"] as! String
//                    self.image = userobj?["image"] as! String
//                    self.isDonor = userobj?["isDonor"] as! Bool
//                    self.status = userobj?["status"] as! Bool
//                    self.iimage = userobj!["image"] as! String
//
//                    let obj = users(name: self.name, age: self.age, bloodgroup: self.bg, rh: self.rh, email: self.email, isDonor: self.isDonor, status: self.status, id: self.userid!, uImage: self.iimage)
//                    self.appdele.arr.append(obj)
//                    print(self.i)
//                    print(self.appdele.arr[self.i].name!)
//                    print(self.appdele.arr[self.i].isDonor!)
//                    print (self.appdele.arr.count)
//
//
//
//                    self.i+=1
//                }//for
//                 self.newcheck()
//            }//if
//        })//observe
//        }
//    }
//
    
   
    
    
    @IBAction func login(_ sender: Any) {
//        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Logout", style: .bordered, target: nil, action: nil)
//        self.navigationItem.backBarButtonItem?.action = #selector(back)
         let sv = UIViewController.displaySpinner(onView: self.view)
         //self.appdele.arr.removeAll()
      
    
        Auth.auth().signIn(withEmail: self.userLabel.text!, password: self.passwordLabel.text!) { (user, error) in
            if error == nil{
                self.performSegue(withIdentifier: "list", sender: self)
      
          }
      
       else  {
                 UIViewController.removeSpinner(spinner: sv)
        let alert=UIAlertController(title: "Error Login", message: "Username or Password may be Wrong", preferredStyle: .alert)
        self.present(alert, animated: true, completion: nil)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
                
            }
    
        
        }
        
      
    }
    override func viewWillAppear(_ animated: Bool) {
        self.userLabel.text = ""
        self.passwordLabel.text = "" }


}
extension UIViewController {
    class func displaySpinner(onView : UIView) -> UIView {
        let spinnerView = UIView.init(frame: onView.bounds)
        spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
        let ai = UIActivityIndicatorView.init(activityIndicatorStyle: .whiteLarge)
        ai.startAnimating()
        ai.center = spinnerView.center
        
        DispatchQueue.main.async {
            spinnerView.addSubview(ai)
            onView.addSubview(spinnerView)
        }
        
        return spinnerView
    }
    
    class func removeSpinner(spinner :UIView) {
        DispatchQueue.main.async {
            spinner.removeFromSuperview()
        }
    }
    
    
    
    
    @objc func back()
    {print("back chla hai")
        do {
            
            try Auth.auth().signOut()
            
            if Auth.auth().currentUser == nil {
                
                // Remove User Session from device
                UserDefaults.standard.removeObject(forKey: "uid")
                UserDefaults.standard.synchronize()
                
                let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "main") as! ViewController
                
            }
            
        } catch let signOutError as NSError {
            
            // handle logout error
            
        }
        
    }
    
    
    
   
    
    
    
    
    
}//CLASS









