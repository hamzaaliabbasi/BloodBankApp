//
//  chatviewcontroller.swift
//  bloodbankingapplication
//
//  Created by Fahad Mirza on 28/11/2018.
//  Copyright © 2018 Fahad Mirza. All rights reserved.
//

import UIKit
import JSQMessagesViewController
import Firebase

class chatviewcontroller: JSQMessagesViewController {

    var ref = Database.database().reference()
    
   
    var donorid = ""
    var did = ""
    var dname = ""
    var receiverdata = ""    
    var receiverid = ""
    var isdonoridentity = ""
    var identity = ""
    var convoid:String?
   
    var useristyping:AnyObject?
    private var localtyping = false
    
    var istyping:Bool{
        get{
            return localtyping
        }
        set{
            
            localtyping = newValue
            self.useristyping?.setValue(newValue)
        }
        
    }
    
   
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func action(sender:AnyObject)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        
    super.viewDidLoad()
        let button1 = UIBarButtonItem(image: UIImage(named: "imagename"), style: .plain, target: self, action:#selector(action(sender:))) // action:#selector(Class.MethodName) for swift 3
        //self.navigationController?.navigationItem = true
        self.navigationItem.rightBarButtonItem  = button1
//   self.did = senderId
    self.dname = senderDisplayName
   self.receiverid = donorid
   self.identity = isdonoridentity
    print(did)
    print(dname)
    print(receiverid)
    
       let recieveridfive = String(self.receiverid.prefix(5))
        let senderidfive = String(self.did.prefix(5))
        
        if (identity == "Yes"){
        convoid = recieveridfive + senderidfive
        }
        else{
            convoid = senderidfive + recieveridfive 
        }
        print(convoid)
       
        
setupbubbles()
        
    collectionView.collectionViewLayout.incomingAvatarViewSize = CGSize.zero
    collectionView.collectionViewLayout.outgoingAvatarViewSize = CGSize.zero
   //  collectionView.frame.size = 500
    
    }
    
    
    
    
    
    
    
    
    
    var incomingbubbleimage: JSQMessagesBubbleImage!
    var outgoingbubbleimage: JSQMessagesBubbleImage!
    var messages = [JSQMessage]()
    
    
    
     func setupbubbles(){
        let factory = JSQMessagesBubbleImageFactory()
        outgoingbubbleimage = (factory?.outgoingMessagesBubbleImage(with: UIColor.jsq_messageBubbleGreen()))!
        
        incomingbubbleimage = (factory?.outgoingMessagesBubbleImage(with: UIColor.jsq_messageBubbleBlue()))!
    }
    
    
 

    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath!) -> UICollectionViewCell{
        
        let cell = super.collectionView(collectionView, cellForItemAt: indexPath) as! JSQMessagesCollectionViewCell
        
        let message = messages[indexPath.item]
        
        if message.senderId == senderId {
            cell.textView.textColor = UIColor.white
        }
        else{
            cell.textView.textColor = UIColor.black
        }
        
        return cell
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageDataForItemAt indexPath: IndexPath!) -> JSQMessageData! {
        return messages[indexPath.item]
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) ->Int {
        return messages.count
    }
    
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAt indexPath: IndexPath!) -> JSQMessageBubbleImageDataSource! {
        
        let message = messages[indexPath.item]
        
        if message.senderId == self.senderId{
           print("yess")
            return outgoingbubbleimage
        }
        else {
            return incomingbubbleimage
        }
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAt indexPath: IndexPath!) -> JSQMessageAvatarImageDataSource! {
        return  nil
    }
    
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, attributedTextForMessageBubbleTopLabelAt indexPath: IndexPath!) -> NSAttributedString!
    {
        return messages[indexPath.item].senderId == senderId ? nil : NSAttributedString(string: messages[indexPath.item].senderDisplayName)
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout!, heightForMessageBubbleTopLabelAt indexPath: IndexPath!) -> CGFloat
    {
        return messages[indexPath.item].senderId == senderId ? 0 : 15
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        observemessages()
   observetyping()
    }
    
    
    
    func addMessage(id: String, text:String){
        
        let message = JSQMessage(senderId: id, displayName: "\(senderDisplayName)", text: text)
     
        messages.append(message!)
        
    
      
    }
    
   
    
  
    
    
    override func didPressSend(_ button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: Date!) {
       let itemRef = ref.child("Messages").child("\(self.convoid!)").childByAutoId()
        
        let messageItem = [
            "text": text,
            "senderId": senderId
        ]
        
        itemRef.setValue(messageItem)
        
   
      JSQSystemSoundPlayer.jsq_playMessageSentSound()
        
        self.finishSendingMessage()
        
    }
   
    
    
    
    func observemessages()
    {
        
        
        let dataref = Database.database().reference()
        print(dataref)
        
        dataref.child("Messages/\(self.convoid!)").queryLimited(toLast: 20).observe(DataEventType.childAdded, with: {(snapshot) in
            
           
            let c = snapshot.value as! [String:Any]
            let id = c["senderId"] as! String
            let text = c["text"] as! String
            
        
        
           
                self.addMessage(id: id , text: text )
            self.automaticallyScrollsToMostRecentMessage = true
          //  self.observetyping()
            self.finishReceivingMessage()
        
        
            
            }
    )
    
    
    }
    
    
    
    private func observetyping(){
        
        let typeindicator = Database.database().reference().child("Messages").child(self.convoid!).child("typingindicator")
        
        useristyping = typeindicator.child(senderId)
        useristyping?.onDisconnectRemoveValue()
        
        let userstypingquery = typeindicator.queryOrderedByValue().queryEqual(toValue: true)
        
        userstypingquery.observe(.value, with: {(snapshot)  in
            
            
            if snapshot.childrenCount == 1 && self.istyping{
                return
                
            }
            
           self.showTypingIndicator = snapshot.childrenCount > 0
            self.scrollToBottom(animated: true)
            
            
            
            
            
            
            
            
            
        })
        
    }
    
    
    
}
