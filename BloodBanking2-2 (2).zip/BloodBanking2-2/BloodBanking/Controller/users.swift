//
//  File.swift
//  BloodBank
//
//  Created by Techsviewer on 6/11/18.
//  Copyright © 2018 test. All rights reserved.
//
import UIKit
import Foundation
class users
{
    var name:String!
    var age:String!
    var bloodgroup:String!
    var rh:String!
   // var password:String!
    var email:String!
  var uImage:String!
    var isDonor:Bool!
    var status:Bool!
    var id:String!
   
    
    init(name:String,age:String,bloodgroup:String,rh:String,email:String,isDonor:Bool,status:Bool,id:String,uImage:String )
    {
        self.name=name
        self.age=age
        self.bloodgroup=bloodgroup
        self.rh=rh
      //  self.password=password
       self.uImage=uImage
        self.email = email
        self.isDonor = isDonor
        self.status = status
        self.id = id
    }
}



