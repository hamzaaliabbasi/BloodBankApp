//
//  List.swift
//  BloodBank
//
//  Created by Techsviewer on 6/11/18.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit
import SDWebImage
import Firebase
import CoreData

class List: UIViewController,UITableViewDelegate,UITableViewDataSource {
 
    let appdele = UIApplication.shared.delegate as! AppDelegate
     var acc:Array<Account>!
     var context:NSManagedObjectContext!
    var s = [Int]()
    var search:Int!
   var x:Int!
    var a:Int!
    var abc:Int!
     var fetch:NSFetchRequest<Account>!
    var check : Int!
    var counting : Int!
    
//    var refresh:UIRefreshControl{
//        let ref = UIRefreshControl()
//        ref.addTarget(self, action: #selector(handleRefresh(_:)), for: .valueChanged)
//
//    return ref
//    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 135.0
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        if(search == 0)
        {
            return data.shareObject.arr.count
            }
        else{
            print(s.count," yeh else m hai s")
            return s.count
            
            
        }
       
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let whiteRoundedView : UIView = UIView(frame: CGRect(x:3,y: 3,width: self.view.frame.size.width - 20,height: 214))
        whiteRoundedView.layer.masksToBounds = false
        whiteRoundedView.layer.cornerRadius = 2.0
        whiteRoundedView.layer.shadowOffset = CGSize(width: -1,height: 1)
        whiteRoundedView.layer.borderWidth = 2
        whiteRoundedView.layer.borderColor = UIColor.black.cgColor
      
       

      
        let cells = tableView.dequeueReusableCell(withIdentifier: "cell") as! cellpreviewTableViewCell
        cells.contentView.addSubview(whiteRoundedView)
        cells.imageview.layer.borderWidth = 1.0
       cells.imageview.layer.masksToBounds = false
        cells.imageview.layer.borderColor = UIColor.white.cgColor
        cells.imageview.layer.cornerRadius = cells.imageview.frame.size.width / 2
        cells.imageview.clipsToBounds = true
        cells.imageview.layer.cornerRadius = cells.imageview.frame.width / 2
        cells.imageview.clipsToBounds = true
        cells.status.text = ""
   cells.status.isHidden = false
//        @objc func handleRefresh(_ control: UIRefreshControl)
//        {
//            data.shareObject.getData()
//            cells.backView.addSubview(refresh)
//            self.tableViews.reloadData()
//            control.endRefreshing()
//        }
        
        
//        func viewWillLayoutSubviews()
//        {super.viewWillLayoutSubviews()
//            cells.imageview.layer.cornerRadius = cells.imageview.frame.size.height / 2;
//            cells.imageview.clipsToBounds =  true
//
//
//        }
        
        
   
        
        if data.shareObject.arr.count != 0 {
            
         if(search == 0)
            
         
         {
        if (data.shareObject.arr[indexPath.row].status == false)
        {
            cells.status.isHidden = true
            }
        
                print("lag gaye")
        cells.userrname.text = data.shareObject.arr[indexPath.row].name
            cells.age.text = "Age: \(data.shareObject.arr[indexPath.row].age!)"
            cells.bloodgroup.text = "BG: \(data.shareObject.arr[indexPath.row].bloodgroup!)"
            cells.rh.text = "Type: \(data.shareObject.arr[indexPath.row].rh!)"
            let url1 : URL = URL(string:data.shareObject.arr[indexPath.row].uImage)!
        
            cells.imageview?.sd_setImage(with: url1)
         
             print(cells.userrname.text)
        
            
            }
        
        if (search==1){   print("else ma lag gaye")
            if (data.shareObject.arr[s[indexPath.row]].status == false)
            {
                cells.status.isHidden = true
            }
            cells.userrname.text = data.shareObject.arr[s[indexPath.row]].name
            cells.age.text = data.shareObject.arr[s[indexPath.row]].age!
            cells.bloodgroup.text = "BG: \(data.shareObject.arr[s[indexPath.row]].bloodgroup!)"
            cells.rh.text = "Type: \(data.shareObject.arr[s[indexPath.row]].rh!)"
             let url1 : URL = URL(string:data.shareObject.arr[s[indexPath.row]].uImage)!
            cells.imageview?.sd_setImage(with: url1)
            print(cells.userrname.text)
            print(cells.age.text)
           
          }//else
     
        
               }
        return cells
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        x=indexPath.row
        performSegue(withIdentifier: "abc", sender: self)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if(segue.identifier == "abc")
        {let Vcnt = segue.destination as! details
        Vcnt.passvalue = x
        }
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete
        {data.shareObject.arr.remove(at: indexPath.row)
            tableViews.reloadData()
        }
    }
    @IBOutlet var tableViews: UITableView!
    @IBAction func serach(_ sender: Any) {
        
        a = 0
        self.s.removeAll()
        if(data.shareObject.arr[self.appdele.mess].isDonor)
        {
            for i in data.shareObject.arr
        {if(i.isDonor == false)
        {s.append(a)
            
            }
            a += 1
            }
            
            }
        else if(data.shareObject.arr[self.appdele.mess].isDonor == false)
        {
            
            for i in data.shareObject.arr
        {if(i.isDonor)
        {s.append(a)
            
            }
            a += 1
            }
            }
        if(abc == 0)
        {
            self.button.setTitle("Get all back", for: .normal)
            search = 1
            abc = 1
            
            
        }
        else if(abc == 1)
        {
            if(data.shareObject.arr[self.appdele.mess].isDonor)
            {self.button.setTitle("Get Recievers only", for: .normal)
                search = 0
                }
            else{
                self.button.setTitle("Get Donors only", for: .normal)
                search = 0
            }
            abc = 0
        }
        print(s.count," yeh hai s ka count")
        print (search, " yeh hai search")
        
        
        self.tableViews.reloadData()
        }//func
    
    
    
    var refreshControl = UIRefreshControl()
    
    @objc func refreshfun(sender:AnyObject) {
        data.shareObject.getData()
        tableViews.reloadData()
        sender.endRefreshing()
    }
    @IBOutlet weak var button: UIButton!
    override func viewDidLoad() {
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(refreshfun(sender:)), for: UIControl.Event.valueChanged)
        tableViews.addSubview(refreshControl) // not required when using UITableViewController
        
        
        
        if data.shareObject.email == nil || data.shareObject.email == ""{
            data.shareObject.getData()
        }
          fetch = Account.fetchRequest()
          context = appdele.persistentContainer.viewContext
        check = 0
        counting = 0
data.shareObject.arr.removeAll()
       
        self.acc = try! self.context.fetch(self.fetch)
        if self.acc.count > 0 {
            print( self.acc.count,"abyyy")
            for i in self.acc{
                
                var obj = users(name: i.name!, age: i.age! , bloodgroup: i.bloodgrp! , rh: i.rh!, email: i.email!, isDonor: i.isDonor , status: i.status, id: i.id!, uImage: i.image!)
                data.shareObject.arr.append(obj)
                
            }}
         print( data.shareObject.arr.count,"abyyy1")
        for i in data.shareObject.arr{
            
            if i.id == Auth.auth().currentUser?.uid {
                print("yeh hai mess", self.appdele.mess)
                self.appdele.mess = counting
                print("vslur of counting = ",counting)
              
                
                
            }
            else{
                counting+=1}}
        
       
     
        search = 0
        abc = 0
        print(self.appdele.mess,"oyeeee")
        
    if(data.shareObject.arr[self.appdele.mess!].isDonor == false)
        {self.button.setTitle("Get Donors only", for: .normal)}
        if(data.shareObject.arr[self.appdele.mess].isDonor)
        {self.button.setTitle("Get Recievers Only", for: .normal)}
        print("Mazeed list m lag gaye")
  
        super.viewDidLoad()
        
       
        tableViews.delegate=self
        tableViews.dataSource=self
        
   
}//viewdidload
    
    
//    @objc func handleRefresh(_ control: UIRefreshControl)
//    {
//        data.shareObject.getData()
//        backView.addSubview(refresh)
//        self.tableViews.reloadData()
//        control.endRefreshing()
//    }
    
    @IBAction func logout(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            
        } catch (let error) {
            print((error as NSError).code)
        }
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "login") as! ViewController
        
       self.navigationController?.pushViewController(controller, animated: true)

    }
    
override func viewWillAppear(_ animated: Bool) {
    
    self.navigationController?.navigationItem.hidesBackButton = true
    self.search = 0
        tableViews.reloadData()
    }
 
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
 
    

}

//extension List {
//    var refresh = UIRefreshContro{
//        let ref = UIRefreshControl()
//        ref.addTarget(self, action: #selector(handleRefresh(_:)), for: .valueChanged)
//        return ref
//    }
//
//    @objc func handleRefresh(_ control: UIRefreshControl)
//    {
//data.shareObject.getData()
//self.tableViews.addSubview(refresh)
//self.tableViews.reloadData()
//        control.endRefreshing()
//}
//}
