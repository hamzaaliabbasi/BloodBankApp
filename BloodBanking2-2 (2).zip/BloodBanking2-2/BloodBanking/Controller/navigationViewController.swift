//
//  navigationViewController.swift
//  BloodBanking
//
//  Created by HAMZA ALI ABBASI on 01/12/2018.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit

class navigationViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

     
    }
    
  
}
