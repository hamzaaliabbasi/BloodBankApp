//
//  tabViewController.swift
//  BloodBanking
//
//  Created by HAMZA ALI ABBASI on 01/12/2018.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit

class tabViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let backButton = UIBarButtonItem (image: UIImage(named: "logout")!, style: .plain, target: self, action: #selector(GoToBack))
        self.navigationItem.leftBarButtonItem = backButton
        self.navigationItem.hidesBackButton = true
        
    }
    
    @objc func GoToBack(){
        print("chl ja bhai")
        self.navigationController!.popViewController(animated: true)
        
    }
    
}
