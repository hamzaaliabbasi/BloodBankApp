//
//  details.swift
//  BloodBanking
//
//  Created by Techsviewer on 6/14/18.
//  Copyright © 2018 test. All rights reserved.
//

import UIKit
import Firebase

class details: UIViewController {
//    let appdele = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var bg: UILabel!
    @IBOutlet weak var rh: UILabel!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var status: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var x = data.shareObject.arr[passvalue]
        self.name.text = "Name: "+x.name!
        self.email.text = "Email: "+x.email!
        self.age.text = "Age: "+x.age!
        self.bg.text = "BG: "+x.bloodgroup!
        self.rh.text = "RH: "+x.rh!
        if(x.status)
        {
            self.status.text = "Status: Available"
        }
        else{
            self.status.text = "Status: Unavailable"
        }
        let url1 : URL = URL(string:x.uImage)!
        
        self.image.sd_setImage(with: url1)
        
        
        self.image.layer.borderWidth = 1.0
        self.image.layer.masksToBounds = false
        self.image.layer.borderColor = UIColor.white.cgColor
        self.image.layer.cornerRadius = self.image.frame.size.width / 2
      self.image.clipsToBounds = true
        self.image.layer.cornerRadius = self.image.frame.width / 2
        self.image.clipsToBounds = true
        
        
        
    }
    var passvalue:Int!
    
    @IBAction func whatsapp(_ sender: Any) {
        
        self.performSegue(withIdentifier: "showChat", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if let segueIndetifier = segue.identifier{
//            if segueIndetifier == "showChat"{
//                let vc = segue.destination as! chatviewcontroller
//                vc.donorid = data.shareObject.arr[passvalue].id!
//                vc.senderDisplayName = data.shareObject.arr[passvalue].name
//                vc.senderId =  Auth.auth().currentUser?.uid
//                print(vc.donorid )
//                print(vc.senderId!)
//                if (data.shareObject.arr[passvalue].isDonor)
//                {
//                    vc.isdonoridentity = "Yes"
//                }
//                else{
//                    vc.isdonoridentity = "No"
//                }
//                print(vc.isdonoridentity)
//
//
//            }else{
//                print("some other segue")
//            }
//        }
//    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //present controller
    
            let Storyboard = UIStoryboard(name: "Main", bundle: nil)
            let DVC = Storyboard.instantiateViewController(withIdentifier: "select") as! chatviewcontroller
    
            DVC.donorid = data.shareObject.arr[passvalue].id!
            DVC.senderDisplayName = data.shareObject.arr[passvalue].name!
            DVC.senderId =  Auth.auth().currentUser?.uid
            print(DVC.donorid )
            print(DVC.senderId!)
            if (data.shareObject.arr[passvalue].isDonor)
            {
            DVC.isdonoridentity = "Yes"
            }
            else{
               DVC.isdonoridentity = "No"
            }
            print(DVC.isdonoridentity)
    
//    self.navigationController?.pushViewController(DVC, animated: true)
    self.present(DVC, animated: true, completion: nil)
    
    //   self.performSegue(withIdentifier: "showChat", sender: self)
    //
    //        func prepare(for segue: UIStoryboardSegue, sender: Any!) {
    //            if(segue.identifier == "showChat")
    //            {let DVC = segue.destination as! chatviewcontroller
    //                DVC.donorid = self.appdele.arr[passvalue].id!
    //                DVC.senderDisplayName = self.appdele.arr[passvalue].name!
    //                DVC.did = Auth.auth().currentUser?.uid ?? ""
    //                DVC.senderId =  Auth.auth().currentUser?.uid
    //                print(DVC.donorid )
    //                print(DVC.senderId!)
    //                if (self.appdele.arr[passvalue].isDonor)
    //                {
    //                    DVC.isdonoridentity = "Yes"
    //                }
    //                else{
    //                    DVC.isdonoridentity = "No"
    //                }
    //            }}
    //  self.navigationController?.pushViewController(DVC, animated: true)
    
    
    
    
    
    
    
    //    }
    }
}
