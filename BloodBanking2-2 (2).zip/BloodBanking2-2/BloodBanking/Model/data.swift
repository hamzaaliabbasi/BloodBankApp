//
//  File.swift
//  BloodBanking
//
//  Created by Tpl Life 02 on 20/02/2019.
//  Copyright © 2019 test. All rights reserved.
//

import Foundation
import UIKit
import CoreData
import Firebase
class data : NSObject{
    var j:Int!
    static var shareObject = data()
    var arr: [users] = []
    var ref:DatabaseReference!
    var i:Int!
    var userid:String!
    var name:String!
    var email:String!
    var age:String!
    var bg:String!
    var rh:String!
    var image:String!
    var isDonor:Bool!
    var  status:Bool!
    var password:String!
    var passvalue:Int!
    var iimage: String!
    var acc:Array<Account>!
    var acca:Account!
     var context:NSManagedObjectContext!
     var fetch:NSFetchRequest<Account>!
    let appdele = UIApplication.shared.delegate as! AppDelegate
    
  
    func getData() {
          context = appdele.persistentContainer.viewContext
          ref = Database.database().reference().child("user")
        self.i = 0
        ref.observe(.value, with: {(snapshot) in
            if (snapshot.childrenCount > 0)
            {
               
                for user in snapshot.children.allObjects as! [DataSnapshot]
                {let userobj = user.value as? [String:Any]
                    self.userid = userobj?["id"] as! String
                    self.name = userobj?["name"] as! String
                    self.email = userobj?["email"] as! String
                    self.age = userobj?["age"] as! String
                    self.bg = userobj?["bloodgrp"] as! String
                    self.rh = userobj!["rh"] as! String
                    self.image = userobj?["image"] as! String
                    self.isDonor = userobj?["isDonor"] as! Bool
                    self.status = userobj?["status"] as! Bool
                    self.iimage = userobj!["image"] as! String
                    
                    let obj = users(name: self.name, age: self.age, bloodgroup: self.bg, rh: self.rh, email: self.email, isDonor: self.isDonor, status: self.status, id: self.userid!, uImage: self.iimage)
                        self.arr.append(obj)
//                    print(self.i)
//                    print(self.appdele.arr[self.i].name!)
//                    print(self.appdele.arr[self.i].isDonor!)
//                    print (self.appdele.arr.count)
//
                    
                    
                    self.i+=1
                }//for
               
            }//if
        })//observe
        newcheck()
    }//getdata()
    
    func newcheck()
    {  fetch = Account.fetchRequest()
        self.i = 0
        print("bahr agae")
        self.acc = try! self.context.fetch(self.fetch)
        print(self.acc.count)
        
        print(self.acc.count,"yeh hai count")
        
        if (self.acc.count == 0 && self.arr.count > 0)
        {
            for s in stride(from: 0, to: self.arr.count, by:1)
            {
                acca = Account(context: self.context)
                self.acca.id = self.arr[s].id!
                self.acca.age = self.arr[s].age!
                self.acca.bloodgrp = self.arr[s].bloodgroup!
                self.acca.email = self.arr[s].email!
                //   self.acca.image = self.image
                self.acca.isDonor = self.arr[s].isDonor!
                self.acca.name = self.arr[s].name!
                //  self.acca.password = self.appdele.arr[s].password!
                self.acca.rh = self.arr[s].rh!
                self.acca.status = self.arr[s].status!
                self.acca.image = self.arr[s].uImage!
                try! self.context.save()
                self.acc = try! self.context.fetch(self.fetch)
                print(self.acc[s].name,self.acc.count)
                
            }//for
        }//if
            
            
        else
        { var lokey = [Int]()
            var yeh = 0
            print("else chl gya hai bhae")
            self.acc = try! self.context.fetch(self.fetch)
            print ("count is greater than one")
            if(arr.count > self.acc.count)
            {print("yeh dekho")
                for y in stride(from: 0, to: self.arr.count, by:1)
                {yeh = 0
                    for i in acc
                    {
                        if(i.id == self.arr[y].id)
                        {yeh = 1}
                    }
                    if( yeh == 0 )
                    {lokey.append(y)
                    }
                }
                
                for p in lokey
                {
                    acca = Account(context: self.context)
                    self.acca.id = self.arr[p].id
                    self.acca.age = self.arr[p].age
                    self.acca.bloodgrp = self.arr[p].bloodgroup
                    self.acca.email = self.arr[p].email
                    self.acca.image = self.arr[p].uImage
                    self.acca.isDonor = self.arr[p].isDonor
                    self.acca.name = self.arr[p].name
                    
                    self.acca.rh = self.arr[p].rh
                    self.acca.status = self.arr[p].status
                    self.acca.image = self.arr[p].uImage
                    print(self.acca.name!,p)
                    try! self.context.save()
                    
                }
            }
            
        }//else
        self.j = 5
    }//newcheck
    
    
}//class
