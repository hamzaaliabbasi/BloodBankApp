//
//  cellpreviewTableViewCell.swift
//  omer
//
//  Created by AxiomHK40 on 10/06/2018.
//  Copyright © 2018 AxiomHK40. All rights reserved.
//

import UIKit

class cellpreviewTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var userrname: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var rh: UILabel!
    @IBOutlet weak var bloodgroup: UILabel!
}
