//
//  ColorTableViewCell.m
//  Demo
//
//  Created by IEMacBook01 on 22/05/16.
//  Copyright © 2016 Iftekhar. All rights reserved.
//

#import "ColorTableViewCell.h"

@implementation ColorTableViewCell

@end
